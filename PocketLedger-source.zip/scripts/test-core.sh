#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd "$(dirname "$0")/.." && pwd)"
task_classes="$(mktemp -d)"
trap 'rm -rf "$task_classes"' EXIT
if command -v javac >/dev/null 2>&1; then task_javac=(javac); else task_javac=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
"${task_javac[@]}" -encoding UTF-8 -d "$task_classes" "$task_root"/app/src/main/java/com/huasir/pocketledger/core/*.java "$task_root"/app/src/test/java/com/huasir/pocketledger/core/CoreChecks.java
java -cp "$task_classes" com.huasir.pocketledger.core.CoreChecks
