"""Host test adapter only. Runs actual LedgerDb SQL in Python's SQLite engine."""
import base64
import sqlite3
import sys

def encode(value):
    return base64.b64encode(str(value).encode('utf-8')).decode('ascii')

def decode(value):
    return base64.b64decode(value).decode('utf-8')

connection = sqlite3.connect(sys.argv[1], isolation_level=None)
for line in sys.stdin:
    parts = line.rstrip('\n').split('\t')
    if parts[0] == 'CLOSE':
        break
    try:
        sql = decode(parts[0])
        arguments = [None if p == 'N' else decode(p[1:]) for p in parts[1:]]
        cursor = connection.execute(sql, arguments)
        columns = [c[0] for c in cursor.description] if cursor.description else []
        rows = cursor.fetchall() if columns else []
        result = ['OK', str(cursor.lastrowid or 0), str(cursor.rowcount), str(len(columns)), str(len(rows))]
        result += [encode(c) for c in columns]
        result += ['N' if c is None else 'S' + encode(c) for r in rows for c in r]
        print('\t'.join(result), flush=True)
    except Exception as error:
        print('ERR\t' + encode(type(error).__name__ + ': ' + str(error)), flush=True)
connection.close()
