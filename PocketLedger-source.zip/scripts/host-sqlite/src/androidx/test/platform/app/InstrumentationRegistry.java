package androidx.test.platform.app;
import android.content.Context;
public final class InstrumentationRegistry {
    public static InstrumentationRegistry getInstrumentation(){return new InstrumentationRegistry();}
    public Context getTargetContext(){return new Context();}
}
