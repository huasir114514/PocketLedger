package androidx.test.ext.junit.runners;
public final class AndroidJUnit4 {}
