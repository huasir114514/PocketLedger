package android.database;
import java.util.*;
public final class Cursor implements AutoCloseable {
    private final List<String> columns;private final List<List<String>> rows;private int position=-1;
    public Cursor(List<String> columns,List<List<String>> rows){this.columns=columns;this.rows=rows;}
    public boolean moveToFirst(){position=0;return !rows.isEmpty();}
    public boolean moveToNext(){position++;return position<rows.size();}
    public String getString(int i){return rows.get(position).get(i);}
    public long getLong(int i){String s=getString(i);return s==null?0:Long.parseLong(s);}
    public int getInt(int i){return (int)getLong(i);}
    public int getColumnIndexOrThrow(String key){int i=columns.indexOf(key);if(i<0)throw new IllegalArgumentException(key);return i;}
    public void close(){}
}
