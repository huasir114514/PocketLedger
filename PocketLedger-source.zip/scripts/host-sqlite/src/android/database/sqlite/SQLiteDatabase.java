package android.database.sqlite;
import android.content.ContentValues;
import android.database.Cursor;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Minimal host adapter, not an Android runtime or a replacement shipped in the app. */
public final class SQLiteDatabase implements AutoCloseable {
    public static final int CONFLICT_IGNORE=4,CONFLICT_REPLACE=5;
    private final Process bridge;private final BufferedReader input;private final BufferedWriter output;
    private boolean success;
    public SQLiteDatabase(String path){
        try{
            bridge=new ProcessBuilder(System.getProperty("ledger.host.python","python"),System.getProperty("ledger.host.bridge"),path).redirectError(ProcessBuilder.Redirect.INHERIT).start();
            input=new BufferedReader(new InputStreamReader(bridge.getInputStream(),StandardCharsets.UTF_8));
            output=new BufferedWriter(new OutputStreamWriter(bridge.getOutputStream(),StandardCharsets.UTF_8));
        }catch(IOException e){throw new RuntimeException(e);}
    }
    private static String enc(Object s){return Base64.getEncoder().encodeToString(s.toString().getBytes(StandardCharsets.UTF_8));}
    private static String dec(String s){return new String(Base64.getDecoder().decode(s),StandardCharsets.UTF_8);}
    private synchronized String[] call(String sql,Object[] args){
        try{
            output.write(enc(sql));if(args!=null)for(Object a:args){output.write('\t');output.write(a==null?"N":"S"+enc(a));}output.newLine();output.flush();
            String line=input.readLine();if(line==null)throw new IllegalStateException("SQLite bridge stopped");String[] result=line.split("\t",-1);
            if(!result[0].equals("OK"))throw new IllegalStateException(dec(result[1]));return result;
        }catch(IOException e){throw new RuntimeException(e);}
    }
    public Cursor rawQuery(String sql,String[] args){
        String[] r=call(sql,args);int columns=Integer.parseInt(r[3]),rows=Integer.parseInt(r[4]),i=5;
        List<String> names=new ArrayList<>();for(int c=0;c<columns;c++)names.add(dec(r[i++]));
        List<List<String>> data=new ArrayList<>();for(int y=0;y<rows;y++){List<String> row=new ArrayList<>();for(int c=0;c<columns;c++){String s=r[i++];row.add(s.equals("N")?null:dec(s.substring(1)));}data.add(row);}
        return new Cursor(names,data);
    }
    public void execSQL(String sql){call(sql,null);}
    public void setForeignKeyConstraintsEnabled(boolean enabled){execSQL("PRAGMA foreign_keys="+(enabled?"ON":"OFF"));}
    public void beginTransaction(){success=false;execSQL("BEGIN EXCLUSIVE");}
    public void setTransactionSuccessful(){success=true;}
    public void endTransaction(){execSQL(success?"COMMIT":"ROLLBACK");}
    public long insertOrThrow(String table,String ignored,ContentValues values){return insertWithOnConflict(table,ignored,values,0);}
    public long insertWithOnConflict(String table,String ignored,ContentValues values,int conflict){
        List<String> names=new ArrayList<>();List<Object> args=new ArrayList<>();for(Map.Entry<String,Object> e:values.valueSet()){names.add(e.getKey());args.add(e.getValue());}
        String mode=conflict==CONFLICT_IGNORE?" OR IGNORE":conflict==CONFLICT_REPLACE?" OR REPLACE":"";
        String sql="INSERT"+mode+" INTO "+table+"("+String.join(",",names)+") VALUES ("+String.join(",",Collections.nCopies(names.size(),"?"))+")";
        String[] r=call(sql,args.toArray());return Long.parseLong(r[2])==0?-1:Long.parseLong(r[1]);
    }
    public int update(String table,ContentValues values,String where,String[] whereArgs){
        List<String> set=new ArrayList<>();List<Object> args=new ArrayList<>();for(Map.Entry<String,Object> e:values.valueSet()){set.add(e.getKey()+"=?");args.add(e.getValue());}if(whereArgs!=null)Collections.addAll(args,whereArgs);
        return Integer.parseInt(call("UPDATE "+table+" SET "+String.join(",",set)+" WHERE "+where,args.toArray())[2]);
    }
    public int delete(String table,String where,String[] args){return Integer.parseInt(call("DELETE FROM "+table+" WHERE "+where,args)[2]);}
    public void close(){try{output.write("CLOSE\n");output.flush();output.close();input.close();bridge.waitFor();}catch(Exception e){throw new RuntimeException(e);}}
}
