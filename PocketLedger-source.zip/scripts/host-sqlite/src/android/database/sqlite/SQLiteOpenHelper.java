package android.database.sqlite;
import android.content.Context;
import android.database.Cursor;
public abstract class SQLiteOpenHelper {
    private final Context context;private final String name;private final int version;private SQLiteDatabase db;
    public SQLiteOpenHelper(Context c,String name,Object ignored,int version){context=c;this.name=name;this.version=version;}
    public SQLiteDatabase getWritableDatabase(){
        if(db==null){db=new SQLiteDatabase(context.getDatabasePath(name).getPath());onConfigure(db);
            int current;try(Cursor c=db.rawQuery("PRAGMA user_version",null)){c.moveToFirst();current=c.getInt(0);}
            if(current==0){onCreate(db);db.execSQL("PRAGMA user_version="+version);}else if(current<version){onUpgrade(db,current,version);db.execSQL("PRAGMA user_version="+version);}
        }return db;
    }
    public SQLiteDatabase getReadableDatabase(){return getWritableDatabase();}
    public void onConfigure(SQLiteDatabase db){}
    public abstract void onCreate(SQLiteDatabase db);
    public abstract void onUpgrade(SQLiteDatabase db,int oldV,int newV);
    public void close(){if(db!=null){db.close();db=null;}}
}
