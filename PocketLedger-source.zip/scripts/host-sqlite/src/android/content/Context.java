package android.content;
import java.io.File;
import java.nio.file.*;
public class Context {
    public File getDatabasePath(String name){return Path.of(System.getProperty("ledger.host.root"),name).toFile();}
    public boolean deleteDatabase(String name){try{return Files.deleteIfExists(getDatabasePath(name).toPath());}catch(java.io.IOException e){throw new RuntimeException(e);}}
}
