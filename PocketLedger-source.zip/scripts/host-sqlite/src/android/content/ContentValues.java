package android.content;
import java.util.*;
public final class ContentValues {
    private final Map<String,Object> values=new LinkedHashMap<>();
    public void put(String key,String value){values.put(key,value);}
    public void put(String key,Integer value){values.put(key,value);}
    public void put(String key,Long value){values.put(key,value);}
    public Set<Map.Entry<String,Object>> valueSet(){return values.entrySet();}
}
