package org.junit;
import java.util.Objects;
public final class Assert {
    public static int assertions;
    public static void assertEquals(long expected,long actual){assertions++;if(expected!=actual)throw new AssertionError("expected="+expected+", actual="+actual);}
    public static void assertEquals(Object expected,Object actual){assertions++;if(!Objects.equals(expected,actual))throw new AssertionError("expected="+expected+", actual="+actual);}
    public static void assertTrue(boolean b){assertions++;if(!b)throw new AssertionError("expected true");}
    public static void assertFalse(boolean b){assertions++;if(b)throw new AssertionError("expected false");}
}
