import java.lang.reflect.*;
import java.nio.file.*;
import org.junit.*;
import com.huasir.pocketledger.LedgerDbTest;
public final class HostDbRunner {
    public static void main(String[] args) throws Exception {
        Path root=Files.createTempDirectory("pocketledger-sqlite-");System.setProperty("ledger.host.root",root.toString());int count=0;
        try{
            for(Method method:LedgerDbTest.class.getMethods())if(method.isAnnotationPresent(Test.class)){
                LedgerDbTest test=new LedgerDbTest();test.setup();
                try{method.invoke(test);System.out.println("PASS: "+method.getName());count++;}
                catch(InvocationTargetException e){throw new AssertionError("FAIL: "+method.getName(),e.getCause());}
                finally{test.teardown();}
            }
            System.out.println("PASS: "+count+" database scenarios, "+Assert.assertions+" assertions (host SQLite adapter; Android runtime not tested)");
        }finally{try(var files=Files.list(root)){for(Path p:files.toList())Files.deleteIfExists(p);}Files.deleteIfExists(root);}
    }
}
