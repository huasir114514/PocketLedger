import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

/** Syntax only: deliberately does not claim Android API compilation. */
class CheckJavaSyntax {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("JDK compiler module required");
        List<String> paths;
        try(Stream<Path> stream=Files.walk(Path.of(args.length==0?"app/src":args[0]))){paths=stream.filter(p->p.toString().endsWith(".java")).map(Path::toString).toList();}
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,Locale.ROOT,java.nio.charset.StandardCharsets.UTF_8)){
            JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("-proc:none","--release","17"),null,manager.getJavaFileObjectsFromStrings(paths));task.parse();
            for(Diagnostic<?> d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(d.toString());
        }
        System.out.println("PASS: Java syntax parsed for "+paths.size()+" source files (Android API compilation not performed)");
    }
}
