#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd "$(dirname "$0")/.." && pwd)"
task_classes="$(mktemp -d)"
trap 'rm -rf "$task_classes"' EXIT
if command -v javac >/dev/null 2>&1; then task_javac=(javac); else task_javac=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
mapfile -t task_sources < <(find "$task_root/scripts/host-sqlite/src" -name '*.java' -type f | sort)
"${task_javac[@]}" -encoding UTF-8 -d "$task_classes" "${task_sources[@]}" "$task_root"/app/src/main/java/com/huasir/pocketledger/core/*.java "$task_root/app/src/main/java/com/huasir/pocketledger/LedgerDb.java" "$task_root/app/src/androidTest/java/com/huasir/pocketledger/LedgerDbTest.java"
java -Dledger.host.bridge="$task_root/scripts/host-sqlite/bridge.py" -Dledger.host.python="$(command -v python3 || command -v python)" -cp "$task_classes" HostDbRunner
