$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
$taskClasses = Join-Path ([System.IO.Path]::GetTempPath()) ([System.Guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $taskClasses | Out-Null
try {
    $sources = Get-ChildItem (Join-Path $taskRoot 'app/src/main/java/com/huasir/pocketledger/core/*.java') | ForEach-Object FullName
    & javac -encoding UTF-8 -d $taskClasses @sources (Join-Path $taskRoot 'app/src/test/java/com/huasir/pocketledger/core/CoreChecks.java')
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
    & java -cp $taskClasses com.huasir.pocketledger.core.CoreChecks
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
} finally { Remove-Item -Recurse -Force $taskClasses }
