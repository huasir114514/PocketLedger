# 只有手机，如何拿到 APK

本项目可以通过 GitHub Actions 云端编译，无需在手机上安装 Java 或安卓 SDK。

如果让助手继续上传和处理构建，只需准备一个**专门用于此 App 的空仓库**：

1. 用手机浏览器打开 [GitHub 新建仓库](https://github.com/new)，登录你的 GitHub。
2. 仓库名字填 `PocketLedger`，可选择 **Private**，勾选 **Add a README file**，然后创建。这样仓库已有默认分支，助手可以提交源码。
3. 把仓库地址发给助手，例如 `https://github.com/你的用户名/PocketLedger`。

当前 GitHub 工具能向已授权的仓库提交代码，但没有新建仓库接口，所以需要你先完成这一小步。如果你的 GitHub 连接仅授权部分仓库，请在 GitHub App 安装设置里把新仓库加入授权范围。

获得仓库地址后，助手可以继续读取仓库状态、上传源码与工作流、处理构建报错，并在构建成功后获取 APK。上传之前尚未发生任何云端构建。

也可以自行从手机使用仓库的 Actions 页面下载：打开 **Build Android APK** 的成功运行，找到 **Artifacts → PocketLedger-debug-apk**，下载 ZIP 并解压，里面的 `app-debug.apk` 才是安装包。

若 GitHub 页面没有按钮，可以在手机浏览器选择“桌面版网站”。不要仅将源码 ZIP 作为仓库附件上传；那样不会自动把工作流放到正确位置。

这是测试版，尚待实机验证。首次构建成功前，不能保证 OCR 和手机后台服务已经验收通过。
