package com.huasir.pocketledger;
import android.content.*;

public final class CaptureReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(!"capture".equals(intent.getAction())||!Settings.capture(context))return;
        CaptureAccessibilityService service=CaptureAccessibilityService.instance;
        if(service==null) {Notices.issue(context,"截图服务没有连接","请在轻记账设置中开启无障碍截图服务。");return;}
        service.capture();
    }
}
