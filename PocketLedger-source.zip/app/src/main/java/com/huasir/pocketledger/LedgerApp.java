package com.huasir.pocketledger;
import android.app.Application;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LedgerApp extends Application {
    public static final ExecutorService WORK = Executors.newSingleThreadExecutor();
    private static LedgerDb db;
    @Override public void onCreate() { super.onCreate(); db=new LedgerDb(this); Notices.channels(this); }
    public static LedgerDb db() { return db; }
}
