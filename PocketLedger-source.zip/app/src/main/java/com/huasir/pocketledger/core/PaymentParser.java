package com.huasir.pocketledger.core;
import java.text.Normalizer;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative expense-only parser. Never guesses among conflicting amounts. */
public final class PaymentParser {
    private static final String NUM = "(?<![0-9.,])((?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]{1,9})(?:\\.[0-9]{1,2})?)(?![0-9.,])";
    private static final Pattern PAID = Pattern.compile("(?:实付(?:金额)?|实际支付|实付款)[\\s:：]*[¥￥]?\\s*"+NUM);
    private static final Pattern LABEL = Pattern.compile("(?:实付(?:金额)?|实际支付|支付金额|付款金额|消费金额|扣款金额|交易金额|已支付|支付了|付款了|扣款|消费|支出)[\\s:：]*[¥￥]?\\s*"+NUM);
    private static final Pattern CURRENCY = Pattern.compile("[¥￥]\\s*"+NUM+"|"+NUM+"\\s*元");
    private static final Pattern STANDALONE = Pattern.compile("(?m)^\\s*-?\\s*([0-9]{1,9}\\.[0-9]{2})\\s*$");
    private PaymentParser() {}
    public static String normalize(String s) {
        return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFKC).replace("\r", "\n").replace('\u00a0',' ');
    }
    public static boolean success(String text) {
        String s=normalize(text).replaceAll("\\s+", "");
        if (s.matches("(?s).*(支付失败|付款失败|交易失败|待支付|待付款|付款中|支付中|退款|退回|收款成功|收钱到账|收款到账|收到转账|转账成功|充值成功|提现成功|到账通知|收入到账).*") ) return false;
        return s.matches("(?s).*(支付成功|付款成功|交易成功|消费成功|扣款成功|成功支付|成功付款|支付完成|付款完成).*");
    }
    public static boolean candidateNotification(String app, String title, String body) {
        if (!Payment.supported(app)) return false;
        String t=normalize(title).replaceAll("\\s+", "");
        boolean trusted = Payment.WECHAT.equals(app) ? t.matches(".*(微信支付|支付凭证).*" )
            : t.matches(".*(支付成功|付款成功|支付宝|支付助手|交易提醒).*" );
        return trusted && success(title+"\n"+body);
    }
    public static Payment parse(String app, String text, long time, int origin, String eventKey) {
        if (!Payment.supported(app) || !success(text)) return null;
        String s=normalize(text);
        Set<Long> preferred=amounts(PAID,s);
        if(preferred.isEmpty())preferred=amounts(LABEL,s);
        if (preferred.size()>1) return null;
        Set<Long> all=preferred.isEmpty() ? amounts(CURRENCY,s) : preferred;
        if (all.isEmpty() && origin==Payment.MANUAL) all=amounts(STANDALONE,s);
        if(all.size()!=1) return null;
        long cents=all.iterator().next();
        if(cents<=0) return null;
        String merchant=first(s,"(?:收款方|商户名称|商家名称|商户|商家)[\\s:：]*([^\\n]{1,50})");
        if(merchant.isEmpty()) merchant=first(s,"向\\s*([^\\n]{1,40}?)\\s*(?:付款|支付)");
        if(merchant.isEmpty()) merchant=Payment.appName(app)+"消费";
        String order=first(s,"(?:微信支付交易单号|支付宝交易号|交易单号|交易号|订单号)[\\s:：]*([A-Za-z0-9_-]{8,64})(?![A-Za-z0-9_-])");
        String funding=Payment.UNKNOWN;
        String channel=first(s,"(?:支付方式|付款方式|扣款账户)[\\s:：]*([^\\n]{1,50})");
        if(channel.matches(".*(银行卡|银行|信用卡|储蓄卡|花呗|余额宝|零钱通|先用后付).*")) funding=Payment.EXTERNAL;
        else if(channel.matches(".*(零钱|余额).*")) funding=Payment.WALLET;
        // Only explicit funding labels can change the wallet balance.
        return new Payment(app,cents,time,origin,merchant,order,funding,s,eventKey);
    }
    private static Set<Long> amounts(Pattern p,String s) {
        Set<Long> out=new LinkedHashSet<>(); Matcher m=p.matcher(s);
        while(m.find()) for(int i=1;i<=m.groupCount();i++) if(m.group(i)!=null) {
            try { out.add(Money.parse(m.group(i).replace(",",""))); } catch (RuntimeException ignored) { }
        }
        return out;
    }
    private static String first(String s,String regex) { Matcher m=Pattern.compile(regex).matcher(s); return m.find() ? m.group(1).trim() : ""; }
}
