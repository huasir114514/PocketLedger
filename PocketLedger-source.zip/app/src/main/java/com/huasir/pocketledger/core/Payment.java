package com.huasir.pocketledger.core;

public final class Payment {
    public static final String WECHAT = "com.tencent.mm", ALIPAY = "com.eg.android.AlipayGphone";
    public static final int MANUAL = 1, AUTO = 2, TYPED = 4;
    public static final String WALLET = "WALLET", EXTERNAL = "EXTERNAL", UNKNOWN = "UNKNOWN";
    public final String app, merchant, orderId, funding, evidence, eventKey;
    public final long cents, time;
    public final int origin;
    public Payment(String app, long cents, long time, int origin, String merchant, String orderId,
                   String funding, String evidence, String eventKey) {
        this.app=app; this.cents=cents; this.time=time; this.origin=origin; this.merchant=merchant;
        this.orderId=orderId; this.funding=funding; this.evidence=evidence; this.eventKey=eventKey;
    }
    public static boolean supported(String app) { return WECHAT.equals(app) || ALIPAY.equals(app); }
    public static String appName(String app) { return WECHAT.equals(app) ? "微信" : "支付宝"; }
    public static String fundingName(String funding) {
        return WALLET.equals(funding) ? "账户余额" : EXTERNAL.equals(funding) ? "银行卡 / 其他" : "付款来源待确认";
    }
}
