package com.huasir.pocketledger;
import android.content.Context;
import android.content.SharedPreferences;

public final class Settings {
    private Settings() {}
    public static SharedPreferences prefs(Context c) {return c.getSharedPreferences("settings",Context.MODE_PRIVATE);}
    public static boolean automatic(Context c) {return prefs(c).getBoolean("auto",false);}
    public static boolean capture(Context c) {return prefs(c).getBoolean("capture",false);}
    public static long window(Context c) {return prefs(c).getInt("window_minutes",10)*60_000L;}
    public static String hash(String s) {
        try {byte[] b=java.security.MessageDigest.getInstance("SHA-256").digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte x:b)out.append(String.format(java.util.Locale.ROOT,"%02x",x & 255));return out.toString();}
        catch(java.security.NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }
}
