package com.huasir.pocketledger.core;

public final class DedupPolicy {
    private DedupPolicy() {}
    public static boolean matches(Payment incoming, Payment existing, int origins, long windowMs) {
        if(!incoming.app.equals(existing.app) || incoming.cents!=existing.cents) return false;
        if(!incoming.orderId.isEmpty() && !existing.orderId.isEmpty()) return incoming.orderId.equals(existing.orderId);
        if(Math.abs(incoming.time-existing.time)>windowMs) return false;
        // Match each manual/automatic observation only once; two real equal-price purchases remain separate.
        return (incoming.origin==Payment.MANUAL && (origins & Payment.AUTO)!=0 && (origins & Payment.MANUAL)==0)
            || (incoming.origin==Payment.AUTO && (origins & Payment.MANUAL)!=0 && (origins & Payment.AUTO)==0);
    }
}
