package com.huasir.pocketledger;
import android.app.Notification;
import android.os.Bundle;
import android.service.notification.*;
import com.huasir.pocketledger.core.*;
import java.util.LinkedHashSet;

public final class PaymentNotificationService extends NotificationListenerService {
    public static volatile boolean connected;
    @Override public void onListenerConnected(){connected=true;Notices.pin(this);}
    @Override public void onListenerDisconnected(){connected=false;}
    @Override public void onDestroy(){connected=false;super.onDestroy();}
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if(!Settings.automatic(this)||!Payment.supported(sbn.getPackageName()))return;
        Notification n=sbn.getNotification();
        if((n.flags & Notification.FLAG_GROUP_SUMMARY)!=0)return;
        Bundle e=n.extras;if(e==null)return;
        // Ordinary chat notifications are not payment evidence.
        if(Notification.MessagingStyle.class.getName().equals(e.getString(Notification.EXTRA_TEMPLATE)))return;
        String title=String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE,""));
        LinkedHashSet<String> parts=new LinkedHashSet<>();
        for(String k:new String[]{Notification.EXTRA_TEXT,Notification.EXTRA_BIG_TEXT,Notification.EXTRA_SUB_TEXT}) {
            CharSequence s=e.getCharSequence(k);if(s!=null&&!s.toString().trim().isEmpty())parts.add(s.toString());
        }
        CharSequence[] lines=e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if(lines!=null)for(CharSequence s:lines)if(s!=null)parts.add(s.toString());
        String body=String.join("\n",parts);
        if(!PaymentParser.candidateNotification(sbn.getPackageName(),title,body))return;
        String text=title+"\n"+body;
        long posted=sbn.getPostTime();
        long when=n.when>0&&Math.abs(n.when-posted)<=24*60*60_000L?n.when:posted;
        // Notification identity + stable when makes content updates idempotent, not later real payments.
        String key="auto:"+Settings.hash(sbn.getPackageName()+"|"+sbn.getKey()+"|"+when);
        LedgerApp.WORK.execute(()->{
            try {
                Payment p=PaymentParser.parse(sbn.getPackageName(),text,when,Payment.AUTO,key);
                if(p==null) {
                    if(LedgerApp.db().addPending(sbn.getPackageName(),text,when,key))Notices.issue(this,"支付消息需要核对","发现支付成功通知，但金额不明确。点击填写金额，避免误记。");
                }else Notices.result(this,p,LedgerApp.db().record(p,Settings.window(this)));
            }catch(RuntimeException error){Notices.issue(this,"这笔没有记上","本地保存出现问题，请打开应用检查并手动补记。");}
        });
    }
}
