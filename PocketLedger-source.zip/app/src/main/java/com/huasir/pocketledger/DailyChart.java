package com.huasir.pocketledger;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.function.IntConsumer;

/** Canvas chart with a real zero baseline, day selection, and accessible description. */
public final class DailyChart extends View {
    private final long[] amounts;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final IntConsumer onDay;private int selected=-1;
    public DailyChart(Context c,long[] amounts,IntConsumer onDay) {
        super(c);this.amounts=amounts;this.onDay=onDay;
        setContentDescription("每日消费柱状图，点击柱子查看当日总额；下方同时列出每一天的金额");setClickable(true);
    }
    private float dp(float n){return n*getResources().getDisplayMetrics().density;}
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);float w=getWidth(),h=getHeight(),left=dp(8),bottom=h-dp(30),top=dp(28),step=(w-dp(16))/amounts.length;
        long max=0;for(long n:amounts)max=Math.max(max,n);
        p.setColor(Color.rgb(217,229,222));p.setStrokeWidth(dp(1));canvas.drawLine(left,bottom,w-left,bottom,p);
        for(int i=0;i<amounts.length;i++) {
            float barH=amounts[i]==0?0:(bottom-top)*amounts[i]/max;
            p.setColor(i==selected?Color.rgb(19,80,65):Color.rgb(70,153,123));
            canvas.drawRoundRect(left+i*step+dp(1),bottom-barH,left+(i+1)*step-dp(1),bottom,dp(3),dp(3),p);
            if(i==0||i==amounts.length-1||(i+1)%5==0) {p.setColor(Color.rgb(110,124,115));p.setTextSize(dp(10));p.setTextAlign(Paint.Align.CENTER);canvas.drawText(""+(i+1),left+(i+.5f)*step,h-dp(8),p);}
        }
        p.setTextSize(dp(11));p.setTextAlign(Paint.Align.LEFT);p.setColor(Color.rgb(110,124,115));
        canvas.drawText("每日支出 · 最高 ¥"+com.huasir.pocketledger.core.Money.format(max),left,dp(15),p);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e) {
        if(e.getAction()==MotionEvent.ACTION_UP){selected=Math.max(0,Math.min(amounts.length-1,(int)((e.getX()-dp(8))/(getWidth()-dp(16))*amounts.length)));invalidate();performClick();onDay.accept(selected+1);return true;}return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
