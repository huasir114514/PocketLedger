package com.huasir.pocketledger;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import com.huasir.pocketledger.core.*;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int GREEN=0xff247b67,INK=0xff162e25,MUTED=0xff73877d,BG=0xfff4f7f5;
    private int tab=0;private YearMonth month=YearMonth.now();
    private LinearLayout body;
    private long renderedVersion=-1;private boolean renderedCapture,renderedListener;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable poll=new Runnable(){@Override public void run(){
        if(renderedVersion!=LedgerApp.db().version() || (tab==3 && (renderedCapture!=(CaptureAccessibilityService.instance!=null)||renderedListener!=PaymentNotificationService.connected)))render();
        handler.postDelayed(this,3000);
    }};
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if(state!=null){tab=state.getInt("tab",0);String m=state.getString("month");if(m!=null)month=YearMonth.parse(m);}
        if(!LedgerApp.db().conflicts().isEmpty()||!LedgerApp.db().pending().isEmpty())tab=2;
    }
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putInt("tab",tab);state.putString("month",month.toString());}
    @Override protected void onResume(){super.onResume();Notices.pin(this);render();handler.postDelayed(poll,6000);}
    @Override protected void onPause(){handler.removeCallbacks(poll);super.onPause();}
    private TextView text(String s,int size,int color) {
        TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(4),0,dp(4));return v;
    }
    private TextView bold(String s,int size,int color){TextView t=text(s,size,color);t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private GradientDrawable background(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private Button button(String label,Runnable click){Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextColor(GREEN);b.setOnClickListener(v->click.run());return b;}
    private LinearLayout card(LinearLayout parent) {
        LinearLayout c=column();c.setPadding(dp(18),dp(16),dp(18),dp(16));c.setBackground(background(Color.WHITE,20));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(14);parent.addView(c,lp);return c;
    }
    private void render() {
        if(isFinishing()||isDestroyed())return;
        renderedVersion=LedgerApp.db().version();renderedCapture=CaptureAccessibilityService.instance!=null;renderedListener=PaymentNotificationService.connected;
        LinearLayout root=column();root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets i=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(i.left,i.top,i.right,i.bottom);return insets;});
        TextView heading=bold("轻记账",26,INK);heading.setPadding(dp(22),dp(14),dp(22),dp(6));root.addView(heading);
        TextView subtitle=text(new String[]{"把每一笔，记得轻一点。","付款留下记录，消费一目了然。","核对一下，让账目更准确。","在本机识别，由你掌握。"}[tab],13,MUTED);
        subtitle.setPadding(dp(22),0,dp(22),dp(12));root.addView(subtitle);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);body=column();body.setPadding(dp(18),dp(6),dp(18),dp(12));sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row();nav.setPadding(dp(6),dp(6),dp(6),dp(6));
        String[] labels={"总览","账单","核对","设置"};int pending=LedgerApp.db().conflicts().size()+LedgerApp.db().pending().size();
        for(int j=0;j<4;j++){final int next=j;Button b=button(labels[j]+(j==2&&pending>0?" · "+pending:""),()->{tab=next;render();});b.setTextSize(14);b.setBackground(background(j==tab?0xffdceee5:BG,14));b.setTextColor(j==tab?GREEN:MUTED);nav.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));}
        root.addView(nav);setContentView(root);root.requestApplyInsets();
        if(tab==0)overview();else if(tab==1)ledger();else if(tab==2)review();else settings();
    }
    private void monthPicker(LinearLayout parent) {
        LinearLayout r=row();r.addView(button("‹",()->{month=month.minusMonths(1);render();}),new LinearLayout.LayoutParams(dp(54),dp(46)));
        TextView t=bold(month.getYear()+" 年 "+month.getMonthValue()+" 月",18,INK);t.setGravity(Gravity.CENTER);r.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        r.addView(button("›",()->{month=month.plusMonths(1);render();}),new LinearLayout.LayoutParams(dp(54),dp(46)));parent.addView(r);
    }
    private List<LedgerDb.Entry> monthEntries(){return LedgerApp.db().entries(LedgerDb.monthStart(month),LedgerDb.monthStart(month.plusMonths(1)));}
    private void overview() {
        if(!com.huasir.pocketledger.Settings.capture(this)&&!com.huasir.pocketledger.Settings.automatic(this)){
            LinearLayout setup=card(body);setup.addView(bold("先录入余额，再开启记账",18,GREEN));setup.addView(text("在下方填写微信零钱和支付宝余额，到设置里开启截图按钮与支付通知。",14,MUTED));setup.addView(button("前往设置",()->{tab=3;render();}));
        }
        LinearLayout balances=card(body);balances.addView(bold("账户余额",17,INK));
        for(String app:new String[]{Payment.WECHAT,Payment.ALIPAY}) {
            LedgerDb.Account a=LedgerApp.db().account(app);LinearLayout r=row();
            LinearLayout left=column();left.addView(text(Payment.appName(app)+(app.equals(Payment.WECHAT)?"零钱":"余额"),14,MUTED));left.addView(bold(a.calibrated?"¥ "+Money.format(a.balance):"待录入",24,INK));r.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            r.addView(button(a.calibrated?"校准":"录入",()->calibrate(app)));balances.addView(r);
        }
        balances.addView(text("仅确认从余额付款的消费会扣减。收入、退款和账户变动后，请重新校准。",12,MUTED));
        LinearLayout stats=card(body);monthPicker(stats);List<LedgerDb.Entry> entries=monthEntries();long total=0;int unknown=0;
        long[] daily=new long[month.lengthOfMonth()];
        for(LedgerDb.Entry e:entries){Payment p=e.payment;total+=p.cents;int day=Instant.ofEpochMilli(p.time).atZone(ZoneId.systemDefault()).getDayOfMonth();daily[day-1]+=p.cents;if(Payment.UNKNOWN.equals(p.funding))unknown++;}
        stats.addView(text("本月支出",14,MUTED));stats.addView(bold("¥ "+Money.format(total),36,GREEN));stats.addView(text(entries.size()+" 笔消费"+(unknown>0?" · "+unknown+" 笔付款来源待确认":""),13,MUTED));
        TextView selection=text("点柱子查看某天的消费",13,GREEN);
        stats.addView(new DailyChart(this,daily,day->{selection.setText(month.getMonthValue()+" 月 "+day+" 日 · ¥ "+Money.format(daily[day-1]));}),new LinearLayout.LayoutParams(-1,dp(165)));stats.addView(selection);
        LinearLayout byDay=card(body);byDay.addView(bold("每日消费",17,INK));
        for(int i=0;i<daily.length;i++){LinearLayout r=row();TextView day=text((i+1)+" 日",14,MUTED);r.addView(day,new LinearLayout.LayoutParams(0,-2,1));r.addView(text("¥ "+Money.format(daily[i]),14,daily[i]>0?INK:MUTED));byDay.addView(r);}
        LinearLayout monthly=card(body);monthly.addView(bold("每月消费",17,INK));SortedMap<YearMonth,Long> totals=LedgerApp.db().monthly();totals.putIfAbsent(YearMonth.now(),0L);
        for(Map.Entry<YearMonth,Long> e:totals.entrySet()){LinearLayout r=row();r.addView(text(e.getKey().toString(),15,MUTED),new LinearLayout.LayoutParams(0,-2,1));r.addView(bold("¥ "+Money.format(e.getValue()),17,INK));r.setOnClickListener(v->{month=e.getKey();tab=1;render();});monthly.addView(r);}
    }
    private void ledger() {
        LinearLayout controls=card(body);monthPicker(controls);controls.addView(button("＋ 补记一笔",()->editDialog(null,null)));
        List<LedgerDb.Entry> entries=monthEntries();
        if(entries.isEmpty()){LinearLayout empty=card(body);empty.addView(bold("这个月还没有消费记录",18,INK));empty.addView(text("开启通知自动记账，或付款后点击通知栏的截图按钮。",14,MUTED));return;}
        for(LedgerDb.Entry e:entries){Payment p=e.payment;LinearLayout c=card(body);LinearLayout r=row();r.addView(bold(p.merchant,17,INK),new LinearLayout.LayoutParams(0,-2,1));r.addView(bold("− ¥"+Money.format(p.cents),20,GREEN));c.addView(r);
            c.addView(text(DateTimeFormatter.ofPattern("MM-dd HH:mm").format(Instant.ofEpochMilli(p.time).atZone(ZoneId.systemDefault()))+" · "+Payment.appName(p.app)+" · "+LedgerDb.originName(e.origins),13,MUTED));
            c.addView(text(Payment.fundingName(p.funding),13,Payment.UNKNOWN.equals(p.funding)?0xffb27425:MUTED));
            c.addView(button("查看 / 修改",()->entryActions(e)));
        }
    }
    private void entryActions(LedgerDb.Entry e) {
        new AlertDialog.Builder(this).setTitle(e.payment.merchant).setItems(new String[]{"修改金额、商家和付款来源","查看识别原文","删除这笔账单"},(d,which)->{
            if(which==0)editDialog(e,null);
            else if(which==1)new AlertDialog.Builder(this).setTitle("本机识别原文").setMessage(e.payment.evidence.trim().isEmpty()?"这笔账单是手动填写的。":e.payment.evidence).setPositiveButton("关闭",null).show();
            else new AlertDialog.Builder(this).setTitle("删除这笔账单？").setMessage("会重新计算消费统计和估算余额。").setNegativeButton("取消",null).setPositiveButton("删除",(a,b)->{LedgerApp.db().delete(e.id);render();}).show();
        }).show();
    }
    private void review() {
        List<LedgerDb.Conflict> conflicts=LedgerApp.db().conflicts();List<LedgerDb.Pending> pending=LedgerApp.db().pending();
        if(conflicts.isEmpty()&&pending.isEmpty()){LinearLayout c=card(body);c.addView(bold("全部核对好了",23,GREEN));c.addView(text("识别不清或疑似重复时，会在这里留下待处理项。",14,MUTED));}
        for(LedgerDb.Conflict x:conflicts){Payment p=x.suppressed;LinearLayout c=card(body);c.addView(bold("我有个问题",19,0xffb27425));c.addView(text(Payment.appName(p.app)+" · ¥ "+Money.format(p.cents)+" · "+p.merchant,16,INK));c.addView(text("两条记账证据疑似来自同一次付款，目前只计一笔。若是两次不同消费，请拆开。",14,MUTED));
            c.addView(button("查看识别依据",()->new AlertDialog.Builder(this).setTitle("后收到的记录").setMessage(p.evidence).setPositiveButton("关闭",null).show()));
            c.addView(button("同一笔，确认合并",()->{LedgerApp.db().resolve(x,false);render();}));c.addView(button("两次消费，恢复两笔",()->{LedgerApp.db().resolve(x,true);render();}));
        }
        for(LedgerDb.Pending x:pending){LinearLayout c=card(body);c.addView(bold("金额或付款状态待确认",18,INK));c.addView(text(Payment.appName(x.app)+" · "+DateTimeFormatter.ofPattern("MM-dd HH:mm").format(Instant.ofEpochMilli(x.time).atZone(ZoneId.systemDefault())),13,MUTED));
            TextView raw=text(x.text.trim().isEmpty()?"没有识别到文字":x.text,13,MUTED);raw.setMaxLines(6);c.addView(raw);
            c.addView(button("填写金额并记账",()->editDialog(null,x)));c.addView(button("忽略这条",()->{LedgerApp.db().dismissPending(x.id);render();}));
        }
    }
    private EditText input(String hint,String value,int type) {EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setInputType(type);return e;}
    private void calibrate(String app) {
        LinearLayout form=column();form.setPadding(dp(20),dp(8),dp(20),dp(8));
        form.addView(text("填写现在看到的实际余额。这会作为新的计算起点；之前的消费不会再重复扣减。",14,MUTED));
        EditText amount=input("当前余额，例如 100.00","",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);form.addView(amount);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(Payment.appName(app)+"余额校准").setView(form).setNegativeButton("取消",null).setPositiveButton("保存",null).create();
        d.setOnShowListener(a->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{LedgerApp.db().calibrate(app,Money.parse(amount.getText().toString()),System.currentTimeMillis());d.dismiss();render();}catch(RuntimeException ex){amount.setError("请输入非负金额，最多两位小数");}}));d.show();
    }
    private Spinner spinner(String[] labels,int selected){Spinner s=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);s.setAdapter(adapter);s.setSelection(selected);return s;}
    private void editDialog(LedgerDb.Entry existing,LedgerDb.Pending pending) {
        Payment old=existing==null?null:existing.payment;LinearLayout form=column();form.setPadding(dp(20),dp(8),dp(20),dp(12));
        String originalApp=old!=null?old.app:pending!=null?pending.app:Payment.WECHAT;
        Spinner apps=spinner(new String[]{"微信","支付宝"},Payment.WECHAT.equals(originalApp)?0:1);form.addView(text("消费应用",13,MUTED));form.addView(apps);if(existing!=null)apps.setEnabled(false);
        EditText amount=input("金额，例如 12.50",old==null?"":Money.format(old.cents),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);form.addView(amount);
        EditText merchant=input("商家 / 备注",old==null?"":old.merchant,InputType.TYPE_CLASS_TEXT);form.addView(merchant);
        String[] funding={Payment.UNKNOWN,Payment.WALLET,Payment.EXTERNAL};Spinner source=spinner(new String[]{"待确认（余额不扣减）","微信零钱 / 支付宝余额","银行卡 / 花呗 / 其他"},old==null?0:Arrays.asList(funding).indexOf(old.funding));
        form.addView(text("付款来源",13,MUTED));form.addView(source);
        long originalTime=old!=null?old.time:pending!=null?pending.time:System.currentTimeMillis();
        ZonedDateTime now=Instant.ofEpochMilli(originalTime).atZone(ZoneId.systemDefault());
        EditText date=input("日期 yyyy-MM-dd",now.toLocalDate().toString(),InputType.TYPE_CLASS_DATETIME);form.addView(date);
        EditText time=input("时间 HH:mm",now.format(DateTimeFormatter.ofPattern("HH:mm")),InputType.TYPE_CLASS_DATETIME);form.addView(time);
        date.setFocusable(false);date.setOnClickListener(v->{LocalDate selected=LocalDate.parse(date.getText().toString());new DatePickerDialog(this,(picker,y,m,day)->date.setText(LocalDate.of(y,m+1,day).toString()),selected.getYear(),selected.getMonthValue()-1,selected.getDayOfMonth()).show();});
        time.setFocusable(false);time.setOnClickListener(v->{LocalTime selected=LocalTime.parse(time.getText().toString());new TimePickerDialog(this,(picker,h,min)->time.setText(String.format(Locale.ROOT,"%02d:%02d",h,min)),selected.getHour(),selected.getMinute(),true).show();});
        if(existing!=null){date.setEnabled(false);time.setEnabled(false);}
        if(pending!=null)form.addView(text("请先确认这是成功的消费付款。识别失败的记录不会自动计入账单。",13,MUTED));
        ScrollView sc=new ScrollView(this);sc.addView(form);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(existing==null?"补记消费":"修改账单").setView(sc).setNegativeButton("取消",null).setPositiveButton("保存",null).create();
        d.setOnShowListener(a->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try {
                long cents=Money.parse(amount.getText().toString());if(cents<=0){amount.setError("消费金额需要大于零");return;}
                String app=apps.getSelectedItemPosition()==0?Payment.WECHAT:Payment.ALIPAY;
                String name=merchant.getText().toString().trim();if(name.isEmpty())name=Payment.appName(app)+"消费";
                String method=funding[source.getSelectedItemPosition()];
                if(existing!=null)LedgerApp.db().edit(existing.id,cents,name,method);
                else {
                    long stamp=LocalDateTime.of(LocalDate.parse(date.getText().toString()),LocalTime.parse(time.getText().toString())).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                    if(date.getText().toString().equals(now.toLocalDate().toString())&&time.getText().toString().equals(now.format(DateTimeFormatter.ofPattern("HH:mm"))))stamp=originalTime;
                    if(stamp>System.currentTimeMillis()+60_000){date.setError("不能记录未来消费");return;}
                    if(pending!=null){
                        LedgerDb.Result result=LedgerApp.db().confirmPending(pending.id,app,cents,stamp,name,method,com.huasir.pocketledger.Settings.window(this));
                        Payment p=new Payment(app,cents,stamp,pending.origin,name,"",method,pending.text,pending.eventKey);Notices.result(this,p,result);
                    }else{
                        Payment p=new Payment(app,cents,stamp,Payment.TYPED,name,"",method,"","typed:"+UUID.randomUUID());LedgerApp.db().record(p,com.huasir.pocketledger.Settings.window(this));
                    }
                }d.dismiss();render();
            }catch(RuntimeException ex){Toast.makeText(this,"请检查金额和日期时间格式",Toast.LENGTH_LONG).show();}
        }));d.show();
    }
    private void settings() {
        LinearLayout state=card(body);state.addView(bold("权限与运行状态",18,INK));
        boolean notification=android.os.Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
        state.addView(text("通知显示："+(notification&&getSystemService(NotificationManager.class).areNotificationsEnabled()?"已允许":"未允许"),14,MUTED));
        state.addView(text("截图服务："+(CaptureAccessibilityService.instance!=null?"已连接":"未连接"),14,MUTED));state.addView(text("通知监听："+(PaymentNotificationService.connected?"已连接":"未连接"),14,MUTED));
        state.addView(button("允许显示通知",()->{
            if(Build.VERSION.SDK_INT>=33&&!notification)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);
            else safeStart(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));
        }));
        LinearLayout capture=card(body);capture.addView(bold("通知栏截图记账",18,INK));
        Switch captureSwitch=new Switch(this);captureSwitch.setText("显示截图按钮");captureSwitch.setChecked(com.huasir.pocketledger.Settings.capture(this));capture.addView(captureSwitch);
        captureSwitch.setOnCheckedChangeListener((b,on)->{
            if(on)disclose("截图记账说明","你点击截图按钮后，应用会收起通知栏并截取当前微信 / 支付宝页面，显示短暂闪光，在本机识别金额。图片不会保存或上传。无障碍服务还会读取窗口所属应用名称，不读取控件内容，不会自动点击付款。",()->{com.huasir.pocketledger.Settings.prefs(this).edit().putBoolean("capture",true).apply();Notices.pin(this);safeStart(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));},()->{captureSwitch.setChecked(false);});
            else{com.huasir.pocketledger.Settings.prefs(this).edit().putBoolean("capture",false).apply();CaptureAccessibilityService service=CaptureAccessibilityService.instance;if(service!=null)service.disableSelf();Notices.pin(this);}
        });
        capture.addView(button("打开无障碍设置",()->safeStart(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));capture.addView(button("恢复通知栏按钮",()->{Notices.pin(this);Toast.makeText(this,"已刷新通知栏按钮",Toast.LENGTH_SHORT).show();}));
        capture.addView(text("开启后，在付款成功页面拉下通知栏，展开轻记账通知，点击“截图记账”。首次侧载安装可能需要先允许“受限设置”。",13,MUTED));
        LinearLayout auto=card(body);auto.addView(bold("支付通知自动记账",18,INK));
        Switch autoSwitch=new Switch(this);autoSwitch.setText("自动记录支付成功通知");autoSwitch.setChecked(com.huasir.pocketledger.Settings.automatic(this));auto.addView(autoSwitch);
        autoSwitch.setOnCheckedChangeListener((b,on)->{
            if(on)disclose("支付通知说明","开启通知使用权后，系统会向服务提供通知。应用仅处理微信和支付宝的支付成功消息，不保存其他应用通知。提取金额后自动记账；无明确金额的消息进入待处理。所有账单和识别文字只保存在本机。",()->{com.huasir.pocketledger.Settings.prefs(this).edit().putBoolean("auto",true).apply();openNotificationAccess();},()->autoSwitch.setChecked(false));
            else com.huasir.pocketledger.Settings.prefs(this).edit().putBoolean("auto",false).apply();
        });
        auto.addView(button("打开通知使用权",this::openNotificationAccess));auto.addView(text("应用内的微信支付服务消息如果没有产生系统通知，无法自动记录，请用截图按钮。自动记账只处理开启后新到的通知。",13,MUTED));
        LinearLayout dedup=card(body);dedup.addView(bold("重复核对范围",18,INK));int current=com.huasir.pocketledger.Settings.prefs(this).getInt("window_minutes",10);
        dedup.addView(button("同应用 + 同金额 · "+current+" 分钟内",()->{int[] times={1,5,10,30,60};new AlertDialog.Builder(this).setTitle("截图和通知匹配时间").setItems(new String[]{"1 分钟","5 分钟","10 分钟（默认）","30 分钟","60 分钟"},(d,i)->{com.huasir.pocketledger.Settings.prefs(this).edit().putInt("window_minutes",times[i]).apply();render();}).show();}));
        dedup.addView(text("同应用、同金额、两种记账方式会先合并并通知核对。不同订单号保持两笔。同种方式的不同消费不会仅因金额相同而合并。",13,MUTED));
        LinearLayout data=card(body);data.addView(bold("账目与数据",18,INK));data.addView(button("导出账单 CSV",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/csv").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"轻记账-"+LocalDate.now()+".csv");startActivityForResult(i,50);}));
        data.addView(text("无需登录。截图只在内存中识别；账单和识别文字保存在应用私有数据库。卸载会删除数据，请先导出账单。余额属于估算值，可随时校准。",13,MUTED));
        data.addView(button("手机后台运行说明",()->new AlertDialog.Builder(this).setTitle("保持服务运行").setMessage("OPPO 等手机：在系统应用设置中允许轻记账后台运行，必要时在最近任务中锁定。Android 14 起，常驻通知也可能被手动划走；可在此恢复。强行停止应用后需重新打开，必要时重新开启服务。\n\n本应用不读取账户真实余额，无法绕过禁止截图的页面；通知中没有付款信息时无法自动记账。").setPositiveButton("知道了",null).show()));
    }
    private void disclose(String title,String message,Runnable accept,Runnable cancel){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setNegativeButton("取消",(d,w)->cancel.run()).setPositiveButton("同意并前往设置",(d,w)->accept.run()).setOnCancelListener(d->cancel.run()).show();}
    private void openNotificationAccess(){NotificationListenerService.requestRebind(new ComponentName(this,PaymentNotificationService.class));safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}
    private void safeStart(Intent i){try{startActivity(i);}catch(ActivityNotFoundException e){Toast.makeText(this,"请在系统设置中搜索相应权限",Toast.LENGTH_LONG).show();}}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);Notices.pin(this);render();}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==50&&result==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();LedgerApp.WORK.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException("无法打开文件");out.write(LedgerApp.db().csv().getBytes(StandardCharsets.UTF_8));runOnUiThread(()->Toast.makeText(this,"账单已导出",Toast.LENGTH_SHORT).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"导出失败，请重试",Toast.LENGTH_LONG).show());}});}}
}
