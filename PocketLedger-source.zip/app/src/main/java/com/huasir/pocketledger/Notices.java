package com.huasir.pocketledger;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import com.huasir.pocketledger.core.*;

public final class Notices {
    static final int PIN=10;
    static final String CONTROL="capture",RESULT="records",ISSUES="issues";
    private Notices() {}
    public static void channels(Context c) {
        NotificationManager m=c.getSystemService(NotificationManager.class);
        m.createNotificationChannel(new NotificationChannel(CONTROL,"截图记账按钮",NotificationManager.IMPORTANCE_LOW));
        m.createNotificationChannel(new NotificationChannel(RESULT,"记账结果",NotificationManager.IMPORTANCE_LOW));
        m.createNotificationChannel(new NotificationChannel(ISSUES,"需要核对",NotificationManager.IMPORTANCE_DEFAULT));
    }
    static PendingIntent main(Context c,int code) {return PendingIntent.getActivity(c,code,new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    public static void pin(Context c) {
        if(!Settings.capture(c)){c.getSystemService(NotificationManager.class).cancel(PIN);return;}
        PendingIntent capture=PendingIntent.getBroadcast(c,11,new Intent(c,CaptureReceiver.class).setAction("capture"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,CONTROL).setSmallIcon(R.drawable.ic_ledger).setContentTitle("轻记账 · 截图记账")
            .setContentText(CaptureAccessibilityService.instance==null ? "截图服务未连接，点此查看设置" : "付款完成后，展开本通知点击截图记账")
            .setContentIntent(main(c,12)).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(null,"截图记账",capture).build()).build();
        post(c,PIN,n);
    }
    static void post(Context c,int id,Notification n) {
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        try{c.getSystemService(NotificationManager.class).notify(id,n);}catch(SecurityException ignored){}
    }
    public static void issue(Context c,String title,String body) {
        post(c,20,new Notification.Builder(c,ISSUES).setSmallIcon(R.drawable.ic_ledger).setContentTitle(title).setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(main(c,20)).build());
    }
    public static void result(Context c,Payment p,LedgerDb.Result r) {
        if("MERGED".equals(r.status)) {
            issue(c,"我有个问题：这两笔是同一次付款吗？",Payment.appName(p.app)+" ¥"+Money.format(p.cents)+" 的记录疑似重复，暂时只记一笔。点击核对，可以恢复成两笔。");
        }else if("REPEAT".equals(r.status)) {
            // Automatic notification replays must remain silent.
            if(p.origin==Payment.MANUAL) issue(c,"这张付款页面已经处理过了","60 秒内相同页面只处理一次，已删除或忽略的记录不会立即重新入账。若是新付款，可以手动补记。");
        }else {
            String note=Payment.UNKNOWN.equals(p.funding)?"；付款来源未确认，余额未扣减":"；"+Payment.fundingName(p.funding);
            post(c,30,new Notification.Builder(c,RESULT).setSmallIcon(R.drawable.ic_ledger).setContentTitle("已记账 ¥"+Money.format(p.cents))
                .setContentText(Payment.appName(p.app)+" · "+p.merchant+note).setAutoCancel(true).setContentIntent(main(c,30)).build());
        }
    }
}
