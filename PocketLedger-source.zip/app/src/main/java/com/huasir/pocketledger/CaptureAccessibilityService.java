package com.huasir.pocketledger;

import android.accessibilityservice.AccessibilityService;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.huasir.pocketledger.core.*;

public final class CaptureAccessibilityService extends AccessibilityService {
    public static volatile CaptureAccessibilityService instance;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private String foreground="";
    private boolean busy;
    private TextRecognizer recognizer;
    private View flashView;
    @Override protected void onServiceConnected() {
        instance=this;recognizer=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());Notices.pin(this);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(event.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED||event.getPackageName()==null)return;
        String pkg=event.getPackageName().toString();
        // Ignore notification shade/IME/our own accessibility overlay; do not retrieve UI nodes.
        if(pkg.equals("com.android.systemui")||pkg.equals(getPackageName())&&busy||pkg.contains("inputmethod"))return;
        foreground=pkg;
    }
    @Override public void onInterrupt() {busy=false;}
    public void capture() {
        if(!Settings.capture(this)||busy)return;
        busy=true;
        boolean dismissed=performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE);
        if(!dismissed) {busy=false;Notices.issue(this,"请重新尝试","系统没有允许收起通知栏。请回到付款成功页后，重新展开通知栏并点击截图按钮。");return;}
        handler.postDelayed(()->{
            String app=foreground;
            if(!Payment.supported(app)) {busy=false;Notices.issue(this,"请停留在付款成功页面","仅识别微信或支付宝。返回对应付款成功页面后再点截图记账。");return;}
            long now=System.currentTimeMillis();
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                    @Override public void onSuccess(ScreenshotResult result) {
                        Bitmap copy=null;
                        try(HardwareBuffer buffer=result.getHardwareBuffer()) {
                            Bitmap hardware=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
                            if(hardware!=null){copy=hardware.copy(Bitmap.Config.ARGB_8888,false);hardware.recycle();}
                        }catch(RuntimeException ignored){}
                        if(copy==null){busy=false;Notices.issue(CaptureAccessibilityService.this,"截图失败","无法读取这张截图，请重试。");return;}
                        flash();recognize(copy,app,now);
                    }
                    @Override public void onFailure(int errorCode) {
                        busy=false;Notices.issue(CaptureAccessibilityService.this,"未能截图","页面可能禁止截屏，或系统暂时拒绝。请稍后重试，也可手动录入。错误码："+errorCode);
                    }
                });
            }catch(RuntimeException e){busy=false;Notices.issue(this,"截图权限不可用","请重新连接无障碍截图服务。");}
        },700);
    }
    private void recognize(Bitmap bitmap,String app,long now) {
        if(recognizer==null){bitmap.recycle();busy=false;return;}
        recognizer.process(InputImage.fromBitmap(bitmap,0))
            .addOnSuccessListener(text->{
                String raw=text.getText(),key="manual:"+Settings.hash(app+"|"+PaymentParser.normalize(raw));
                LedgerApp.WORK.execute(()->{
                    try {
                        Payment p=PaymentParser.parse(app,raw,now,Payment.MANUAL,key);
                        if(p==null){
                            LedgerApp.db().addPending(app,raw,now,key);
                            Notices.issue(this,"这张截图需要核对","未能确定付款成功和唯一金额，已放入待处理。点击填写金额。");
                        }else Notices.result(this,p,LedgerApp.db().record(p,Settings.window(this)));
                    }catch(RuntimeException e){Notices.issue(this,"这笔没有记上","保存失败，请打开应用检查并手动补记。");}
                });
            })
            .addOnFailureListener(e->Notices.issue(this,"文字识别失败","没有新增账单。请重试或手动录入。"))
            .addOnCompleteListener(task->{bitmap.recycle();busy=false;});
    }
    private void flash() {
        WindowManager wm=getSystemService(WindowManager.class);
        View v=new View(this);v.setBackgroundColor(Color.WHITE);v.setAlpha(.65f);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        try{wm.addView(v,lp);flashView=v;v.animate().alpha(0).setDuration(240).withEndAction(()->removeFlash()).start();}catch(RuntimeException ignored){}
    }
    private void removeFlash(){if(flashView!=null){try{getSystemService(WindowManager.class).removeView(flashView);}catch(RuntimeException ignored){}flashView=null;}}
    @Override public void onDestroy() {
        if(instance==this)instance=null;handler.removeCallbacksAndMessages(null);removeFlash();
        if(recognizer!=null){recognizer.close();recognizer=null;}Notices.pin(this);super.onDestroy();
    }
}
