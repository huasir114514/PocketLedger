package com.huasir.pocketledger;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.huasir.pocketledger.core.*;
import java.time.*;
import java.util.*;

public final class LedgerDb extends SQLiteOpenHelper {
    private long version;
    public synchronized long version(){return version;}
    public static final class Entry {
        public final long id; public final Payment payment; public final int origins;
        Entry(long id, Payment p, int origins) { this.id=id; payment=p; this.origins=origins; }
    }
    public static final class Conflict {
        public final long id, entryId; public final Payment suppressed;
        Conflict(long id,long entryId,Payment p) { this.id=id;this.entryId=entryId;suppressed=p; }
    }
    public static final class Pending {
        public final long id,time; public final String app,text,eventKey;public final int origin;
        Pending(long id,long time,String app,String text,String eventKey) {
            this.id=id;this.time=time;this.app=app;this.text=text;
            this.eventKey=eventKey.replaceFirst("^(manual:[0-9a-f]{64}):[0-9]+$","$1");
            this.origin=eventKey.startsWith("auto:")?Payment.AUTO:Payment.MANUAL;
        }
    }
    public static final class Result {
        public final String status; public final long entryId;
        Result(String status,long entryId) {this.status=status;this.entryId=entryId;}
    }
    public static final class Account {
        public final boolean calibrated; public final long balance, anchor;
        Account(boolean c,long b,long a) {calibrated=c;balance=b;anchor=a;}
    }
    public LedgerDb(Context c) {this(c,"ledger.db");}
    LedgerDb(Context c,String name) {super(c,name,null,2);}
    @Override public void onConfigure(SQLiteDatabase db) {db.setForeignKeyConstraintsEnabled(true);}
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, app TEXT NOT NULL, cents INTEGER NOT NULL CHECK(cents>0), time INTEGER NOT NULL, origins INTEGER NOT NULL, merchant TEXT NOT NULL, order_id TEXT NOT NULL, funding TEXT NOT NULL, evidence TEXT NOT NULL)");
        db.execSQL("CREATE INDEX entries_match ON entries(app,cents,time)");
        db.execSQL("CREATE TABLE events(event_key TEXT PRIMARY KEY, time INTEGER NOT NULL, entry_id INTEGER NOT NULL REFERENCES entries(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE conflicts(id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id INTEGER NOT NULL REFERENCES entries(id) ON DELETE CASCADE, app TEXT NOT NULL, cents INTEGER NOT NULL, time INTEGER NOT NULL, origin INTEGER NOT NULL, merchant TEXT NOT NULL, order_id TEXT NOT NULL, funding TEXT NOT NULL, evidence TEXT NOT NULL, event_key TEXT NOT NULL, old_origins INTEGER NOT NULL, old_funding TEXT NOT NULL, old_order TEXT NOT NULL, reviewed INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE pending(id INTEGER PRIMARY KEY AUTOINCREMENT, app TEXT NOT NULL, time INTEGER NOT NULL, evidence TEXT NOT NULL, event_key TEXT NOT NULL UNIQUE)");
        db.execSQL("CREATE TABLE accounts(app TEXT PRIMARY KEY, base INTEGER NOT NULL, anchor INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE ignored_events(event_key TEXT PRIMARY KEY, time INTEGER NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {
        if(oldV<2)db.execSQL("CREATE TABLE ignored_events(event_key TEXT PRIMARY KEY, time INTEGER NOT NULL)");
    }
    private ContentValues values(Payment p) {
        ContentValues v=new ContentValues();v.put("app",p.app);v.put("cents",p.cents);v.put("time",p.time);
        v.put("merchant",p.merchant);v.put("order_id",p.orderId);v.put("funding",p.funding);v.put("evidence",p.evidence);
        return v;
    }
    public synchronized Result record(Payment p,long windowMs) {
        validate(p);
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        Result result;
        try {
            result=recordInsideTransaction(db,p,windowMs);db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        if(!"REPEAT".equals(result.status))version++;
        return result;
    }
    private static void validate(Payment p){
        if(!Payment.supported(p.app)||p.cents<=0||p.cents>100_000_000_000L||p.time<0
           ||(p.origin!=Payment.MANUAL&&p.origin!=Payment.AUTO&&p.origin!=Payment.TYPED)
           ||(!Payment.WALLET.equals(p.funding)&&!Payment.EXTERNAL.equals(p.funding)&&!Payment.UNKNOWN.equals(p.funding)))
            throw new IllegalArgumentException("无效的账单字段");
    }
    private Result recordInsideTransaction(SQLiteDatabase db,Payment p,long windowMs) {
            if(ignored(db,p.eventKey,p.time,p.origin))return new Result("REPEAT",0);
            if(!p.eventKey.isEmpty()) try(Cursor c=db.rawQuery("SELECT time,entry_id FROM events WHERE event_key=?",new String[]{p.eventKey})) {
                if(c.moveToFirst() && (p.origin!=Payment.MANUAL || Math.abs(p.time-c.getLong(0))<60_000)) {
                    return new Result("REPEAT",c.getLong(1));
                }
            }
            Entry matched=null;
            try(Cursor c=db.rawQuery("SELECT * FROM entries WHERE app=? AND cents=? AND (time BETWEEN ? AND ? OR (order_id<>'' AND order_id=?)) ORDER BY ABS(time-?) ASC,id DESC",
                new String[]{p.app,""+p.cents,""+(p.time-windowMs),""+(p.time+windowMs),p.orderId,""+p.time})) {
                while(c.moveToNext()) {Entry e=entry(c);if(DedupPolicy.matches(p,e.payment,e.origins,windowMs)){matched=e;break;}}
            }
            long id;
            if(matched!=null) {
                id=matched.id;
                if((matched.origins & p.origin)!=0 && !p.orderId.isEmpty() && p.orderId.equals(matched.payment.orderId)) {
                    ContentValues event=new ContentValues();event.put("event_key",p.eventKey);event.put("time",p.time);event.put("entry_id",id);
                    if(!p.eventKey.isEmpty())db.insertWithOnConflict("events",null,event,SQLiteDatabase.CONFLICT_REPLACE);
                    return new Result("REPEAT",id);
                }
                ContentValues update=new ContentValues();update.put("origins",matched.origins|p.origin);
                if(matched.payment.orderId.isEmpty()&&!p.orderId.isEmpty()) update.put("order_id",p.orderId);
                if(Payment.UNKNOWN.equals(matched.payment.funding)&&!Payment.UNKNOWN.equals(p.funding)) update.put("funding",p.funding);
                db.update("entries",update,"id=?",new String[]{""+id});
                ContentValues conflict=values(p);conflict.put("entry_id",id);conflict.put("origin",p.origin);conflict.put("event_key",p.eventKey);
                conflict.put("old_origins",matched.origins);conflict.put("old_funding",matched.payment.funding);conflict.put("old_order",matched.payment.orderId);
                db.insertOrThrow("conflicts",null,conflict);
            } else { ContentValues v=values(p);v.put("origins",p.origin);id=db.insertOrThrow("entries",null,v); }
            if(!p.eventKey.isEmpty()) {ContentValues event=new ContentValues();event.put("event_key",p.eventKey);event.put("time",p.time);event.put("entry_id",id);db.insertWithOnConflict("events",null,event,SQLiteDatabase.CONFLICT_REPLACE);}
            db.delete("pending","event_key=?",new String[]{p.eventKey});
            return new Result(matched==null?"ADDED":"MERGED",id);
    }
    private static boolean ignored(SQLiteDatabase db,String key,long time,int origin){
        try(Cursor c=db.rawQuery("SELECT time FROM ignored_events WHERE event_key=?",new String[]{key})){
            return c.moveToFirst()&&(origin!=Payment.MANUAL||Math.abs(time-c.getLong(0))<60_000);
        }
    }
    private static String str(Cursor c,String name) {return c.getString(c.getColumnIndexOrThrow(name));}
    private static long number(Cursor c,String name) {return c.getLong(c.getColumnIndexOrThrow(name));}
    private static Payment payment(Cursor c,int origin) {
        return new Payment(str(c,"app"),number(c,"cents"),number(c,"time"),origin,str(c,"merchant"),str(c,"order_id"),str(c,"funding"),str(c,"evidence"),"");
    }
    private static Entry entry(Cursor c) {int origins=(int)number(c,"origins");return new Entry(number(c,"id"),payment(c,origins),origins);}
    public synchronized List<Entry> entries(long start,long end) {
        List<Entry> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM entries WHERE time>=? AND time<? ORDER BY time DESC,id DESC",new String[]{""+start,""+end})) {while(c.moveToNext())out.add(entry(c));}
        return out;
    }
    public synchronized List<Conflict> conflicts() {
        List<Conflict> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM conflicts WHERE reviewed=0 ORDER BY id DESC",null)) {
            while(c.moveToNext())out.add(new Conflict(number(c,"id"),number(c,"entry_id"),payment(c,(int)number(c,"origin"))));
        } return out;
    }
    public synchronized void resolve(Conflict conflict,boolean separate) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            try(Cursor check=db.rawQuery("SELECT reviewed FROM conflicts WHERE id=?",new String[]{""+conflict.id})) {
                if(!check.moveToFirst()||check.getInt(0)!=0){db.setTransactionSuccessful();return;}
            }
            if(separate) {
                Payment p=conflict.suppressed;ContentValues v=values(p);v.put("origins",p.origin);long newId=db.insertOrThrow("entries",null,v);
                // Undo metadata enrichment as well as origin flags when the user restores two real payments.
                try(Cursor c=db.rawQuery("SELECT old_origins,old_funding,old_order,event_key FROM conflicts WHERE id=?",new String[]{""+conflict.id})) {
                    if(c.moveToFirst()) {
                        ContentValues u=new ContentValues();u.put("origins",c.getInt(0));u.put("funding",c.getString(1));u.put("order_id",c.getString(2));
                        db.update("entries",u,"id=?",new String[]{""+conflict.entryId});
                        ContentValues move=new ContentValues();move.put("entry_id",newId);db.update("events",move,"event_key=?",new String[]{c.getString(3)});
                    }
                }
            }
            ContentValues done=new ContentValues();done.put("reviewed",1);db.update("conflicts",done,"id=?",new String[]{""+conflict.id});db.setTransactionSuccessful();version++;
        }finally{db.endTransaction();}
    }
    public synchronized boolean addPending(String app,String text,long time,String key) {
        SQLiteDatabase db=getWritableDatabase();
        if(ignored(db,key,time,key.startsWith("auto:")?Payment.AUTO:Payment.MANUAL))return false;
        try(Cursor c=db.rawQuery("SELECT 1 FROM events WHERE event_key=?",new String[]{key})) {if(c.moveToFirst())return false;}
        ContentValues v=new ContentValues();v.put("app",app);v.put("time",time);v.put("evidence",text);v.put("event_key",key);
        boolean inserted=db.insertWithOnConflict("pending",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;if(inserted)version++;return inserted;
    }
    public synchronized List<Pending> pending() {
        List<Pending> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM pending ORDER BY id DESC",null)) {
            while(c.moveToNext())out.add(new Pending(number(c,"id"),number(c,"time"),str(c,"app"),str(c,"evidence"),str(c,"event_key")));
        }return out;
    }
    public synchronized Result confirmPending(long id,String app,long cents,long time,String merchant,String funding,long windowMs){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();Result result;
        try{
            Pending item;
            try(Cursor c=db.rawQuery("SELECT * FROM pending WHERE id=?",new String[]{""+id})){
                if(!c.moveToFirst()){db.setTransactionSuccessful();return new Result("REPEAT",0);}
                item=new Pending(id,number(c,"time"),str(c,"app"),str(c,"evidence"),str(c,"event_key"));
            }
            Payment p=new Payment(app,cents,time,item.origin,merchant,"",funding,item.text,item.eventKey);validate(p);
            result=recordInsideTransaction(db,p,windowMs);
            db.delete("pending","id=?",new String[]{""+id});db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        version++;return result;
    }
    private static void ignore(SQLiteDatabase db,String key,long time){ContentValues v=new ContentValues();v.put("event_key",key);v.put("time",time);db.insertWithOnConflict("ignored_events",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public synchronized void dismissPending(long id) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            try(Cursor c=db.rawQuery("SELECT event_key,time FROM pending WHERE id=?",new String[]{""+id})){
                if(c.moveToFirst())ignore(db,c.getString(0).replaceFirst("^(manual:[0-9a-f]{64}):[0-9]+$","$1"),c.getLong(1));
            }
            db.delete("pending","id=?",new String[]{""+id});db.setTransactionSuccessful();
        }finally{db.endTransaction();}version++;
    }
    public synchronized void edit(long id,long cents,String merchant,String funding) {
        ContentValues v=new ContentValues();v.put("cents",cents);v.put("merchant",merchant);v.put("funding",funding);
        getWritableDatabase().update("entries",v,"id=?",new String[]{""+id});version++;
    }
    public synchronized void delete(long id) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            try(Cursor c=db.rawQuery("SELECT event_key,time FROM events WHERE entry_id=?",new String[]{""+id})){
                while(c.moveToNext())ignore(db,c.getString(0),c.getLong(1));
            }
            db.delete("entries","id=?",new String[]{""+id});db.setTransactionSuccessful();
        }finally{db.endTransaction();}version++;
    }
    public synchronized void calibrate(String app,long cents,long now) {
        ContentValues v=new ContentValues();v.put("app",app);v.put("base",cents);v.put("anchor",now);
        getWritableDatabase().insertWithOnConflict("accounts",null,v,SQLiteDatabase.CONFLICT_REPLACE);version++;
    }
    public synchronized Account account(String app) {
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("SELECT base,anchor FROM accounts WHERE app=?",new String[]{app})) {
            if(!c.moveToFirst())return new Account(false,0,0);
            long base=c.getLong(0),anchor=c.getLong(1);
            try(Cursor sum=db.rawQuery("SELECT COALESCE(SUM(cents),0) FROM entries WHERE app=? AND funding=? AND time>?",new String[]{app,Payment.WALLET,""+anchor})) {
                sum.moveToFirst();return new Account(true,base-sum.getLong(0),anchor);
            }
        }
    }
    public static long monthStart(YearMonth m) {return m.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();}
    public synchronized SortedMap<YearMonth,Long> monthly() {
        SortedMap<YearMonth,Long> out=new TreeMap<>(Comparator.reverseOrder());
        try(Cursor c=getReadableDatabase().rawQuery("SELECT time,cents FROM entries",null)) {
            while(c.moveToNext()) {YearMonth m=YearMonth.from(Instant.ofEpochMilli(c.getLong(0)).atZone(ZoneId.systemDefault()));out.put(m,out.getOrDefault(m,0L)+c.getLong(1));}
        }return out;
    }
    public synchronized String csv() {
        StringBuilder b=new StringBuilder("\uFEFF日期,应用,金额,商家,付款来源,记账方式,订单号\r\n");
        for(Entry e:entries(0,Long.MAX_VALUE)) {Payment p=e.payment;
            String[] row={Instant.ofEpochMilli(p.time).atZone(ZoneId.systemDefault()).toLocalDateTime().toString(),Payment.appName(p.app),Money.format(p.cents),p.merchant,Payment.fundingName(p.funding),originName(e.origins),p.orderId};
            for(int i=0;i<row.length;i++){if(i>0)b.append(',');String s=row[i];if(s.matches("^[=+@\\-].*"))s="'"+s;b.append('"').append(s.replace("\"","\"\"")).append('"');}b.append("\r\n");
        }return b.toString();
    }
    public static String originName(int mask) {
        if((mask & 3)==3)return "截图 + 通知";if((mask & Payment.MANUAL)!=0)return "截图";if((mask & Payment.AUTO)!=0)return "通知";return "手动录入";
    }
}
