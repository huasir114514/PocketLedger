package com.huasir.pocketledger.core;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

public final class Money {
    private Money() {}
    public static long parse(String value) {
        if (value == null || !value.trim().matches("[0-9]+(?:\\.[0-9]{1,2})?")) throw new IllegalArgumentException("请输入金额，最多两位小数");
        long cents = new BigDecimal(value.trim()).setScale(2, RoundingMode.UNNECESSARY).movePointRight(2).longValueExact();
        if (cents > 100_000_000_000L) throw new IllegalArgumentException("金额过大");
        return cents;
    }
    public static String format(long cents) { return String.format(Locale.CHINA, "%s%d.%02d", cents < 0 ? "-" : "", Math.abs(cents)/100, Math.abs(cents)%100); }
}
