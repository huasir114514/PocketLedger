package com.huasir.pocketledger;
import android.content.Context;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.*;
import org.junit.runner.RunWith;
import com.huasir.pocketledger.core.*;
import java.time.YearMonth;
import static org.junit.Assert.*;

/** Executes against real Android SQLite, never the user's ledger.db. */
@RunWith(AndroidJUnit4.class)
public class LedgerDbTest {
    private Context context;private LedgerDb db;private final String name="ledger-test-only.db";
    @Before public void setup(){context=InstrumentationRegistry.getInstrumentation().getTargetContext();context.deleteDatabase(name);db=new LedgerDb(context,name);}
    @After public void teardown(){db.close();context.deleteDatabase(name);}
    private Payment p(int source,long time,String key,String funding){return new Payment(Payment.WECHAT,1200,time,source,"测试商家","",funding,"测试付款成功 12.00元",key);}
    private int count(){return db.entries(0,Long.MAX_VALUE).size();}
    @Test public void bothObservationOrdersMergeOnce(){
        db.calibrate(Payment.WECHAT,10000,100);
        db.record(p(Payment.MANUAL,200,"m1",Payment.WALLET),600000);
        assertEquals("MERGED",db.record(p(Payment.AUTO,300,"a1",Payment.WALLET),600000).status);
        assertEquals(1,count());assertEquals(8800,db.account(Payment.WECHAT).balance);assertEquals(1,db.conflicts().size());
        db.record(p(Payment.AUTO,1000000,"a2",Payment.WALLET),600000);
        assertEquals("MERGED",db.record(p(Payment.MANUAL,1000010,"m2",Payment.WALLET),600000).status);
        assertEquals(2,count());assertEquals(7600,db.account(Payment.WECHAT).balance);
    }
    @Test public void restoreTwoPaymentsAndMetadata(){
        db.calibrate(Payment.WECHAT,10000,100);
        db.record(p(Payment.MANUAL,200,"m",Payment.UNKNOWN),600000);
        db.record(p(Payment.AUTO,300,"a",Payment.WALLET),600000);
        assertEquals(8800,db.account(Payment.WECHAT).balance);
        LedgerDb.Conflict x=db.conflicts().get(0);db.resolve(x,true);assertEquals(2,count());assertTrue(db.conflicts().isEmpty());
        assertEquals(Payment.UNKNOWN,db.entries(0,Long.MAX_VALUE).get(1).payment.funding);
        assertEquals(8800,db.account(Payment.WECHAT).balance);db.resolve(x,true);assertEquals(2,count());
        assertEquals("REPEAT",db.record(p(Payment.AUTO,300,"a",Payment.WALLET),600000).status);
    }
    @Test public void calibratedBalanceDoesNotDeductOldSpending(){
        db.record(p(Payment.MANUAL,100,"m",Payment.WALLET),600000);db.calibrate(Payment.WECHAT,10000,200);
        assertEquals(10000,db.account(Payment.WECHAT).balance);
        db.record(p(Payment.MANUAL,300,"m2",Payment.EXTERNAL),600000);assertEquals(10000,db.account(Payment.WECHAT).balance);
        db.record(p(Payment.MANUAL,400,"m3",Payment.UNKNOWN),600000);assertEquals(10000,db.account(Payment.WECHAT).balance);
        LedgerDb.Result r=db.record(p(Payment.MANUAL,500,"m4",Payment.WALLET),600000);assertEquals(8800,db.account(Payment.WECHAT).balance);
        db.delete(r.entryId);assertEquals(10000,db.account(Payment.WECHAT).balance);
    }
    @Test public void eventReplaySurvivesDatabaseReopen(){
        db.record(p(Payment.AUTO,100,"stable",Payment.WALLET),600000);db.close();db=new LedgerDb(context,name);
        assertEquals("REPEAT",db.record(p(Payment.AUTO,100,"stable",Payment.WALLET),600000).status);assertEquals(1,count());
    }
    @Test public void equalPriceSameSourceIsNotMerged(){db.record(p(Payment.AUTO,100,"a",Payment.UNKNOWN),600000);db.record(p(Payment.AUTO,101,"b",Payment.UNKNOWN),600000);assertEquals(2,count());}
    @Test public void twoConsumedPairsRemainTwoPayments(){
        db.record(p(Payment.MANUAL,100,"m1",Payment.UNKNOWN),600000);db.record(p(Payment.AUTO,101,"a1",Payment.UNKNOWN),600000);
        db.record(p(Payment.AUTO,102,"a2",Payment.UNKNOWN),600000);db.record(p(Payment.MANUAL,103,"m2",Payment.UNKNOWN),600000);assertEquals(2,count());
    }
    @Test public void confirmationKeepsOnePayment(){db.record(p(Payment.MANUAL,100,"m",Payment.UNKNOWN),600000);db.record(p(Payment.AUTO,101,"a",Payment.UNKNOWN),600000);db.resolve(db.conflicts().get(0),false);assertEquals(1,count());assertTrue(db.conflicts().isEmpty());}
    @Test public void monthlyTotalsRespectLocalMonthBoundary(){
        YearMonth month=YearMonth.of(2026,10);long start=LedgerDb.monthStart(month);
        db.record(p(Payment.TYPED,start-1,"p",Payment.UNKNOWN),600000);db.record(p(Payment.TYPED,start,"q",Payment.UNKNOWN),600000);
        assertEquals(1,db.entries(start,LedgerDb.monthStart(month.plusMonths(1))).size());assertEquals(Long.valueOf(1200),db.monthly().get(month));
    }
    @Test public void editingRecomputesBalance(){db.calibrate(Payment.WECHAT,10000,100);LedgerDb.Result r=db.record(p(Payment.MANUAL,200,"m",Payment.WALLET),600000);db.edit(r.entryId,1500,"修改",Payment.WALLET);assertEquals(8500,db.account(Payment.WECHAT).balance);db.edit(r.entryId,1500,"修改",Payment.EXTERNAL);assertEquals(10000,db.account(Payment.WECHAT).balance);}
    @Test public void pendingRecognitionIsIdempotent(){assertTrue(db.addPending(Payment.WECHAT,"不清晰",100,"k"));assertFalse(db.addPending(Payment.WECHAT,"不清晰",100,"k"));assertEquals(1,db.pending().size());db.dismissPending(db.pending().get(0).id);assertTrue(db.pending().isEmpty());}
    @Test public void correctedScreenshotStillMergesWithAutomaticPayment(){
        db.calibrate(Payment.WECHAT,10000,50);db.addPending(Payment.WECHAT,"截图金额模糊",100,"manual:pending");long id=db.pending().get(0).id;
        assertEquals("ADDED",db.confirmPending(id,Payment.WECHAT,1200,100,"测试",Payment.WALLET,600000).status);
        assertEquals("REPEAT",db.confirmPending(id,Payment.WECHAT,1200,100,"测试",Payment.WALLET,600000).status);
        assertEquals("MERGED",db.record(p(Payment.AUTO,110,"auto:new",Payment.WALLET),600000).status);
        assertEquals(1,count());assertEquals(8800,db.account(Payment.WECHAT).balance);assertEquals(3,db.entries(0,Long.MAX_VALUE).get(0).origins);
    }
    @Test public void correctedAutomaticMessageRetainsItsEventIdentity(){
        db.record(p(Payment.MANUAL,100,"manual:first",Payment.WALLET),600000);db.addPending(Payment.WECHAT,"通知金额模糊",110,"auto:pending");long id=db.pending().get(0).id;
        assertEquals("MERGED",db.confirmPending(id,Payment.WECHAT,1200,110,"测试",Payment.WALLET,600000).status);
        assertEquals("REPEAT",db.record(p(Payment.AUTO,110,"auto:pending",Payment.WALLET),600000).status);assertEquals(1,count());assertTrue(db.pending().isEmpty());
    }
    @Test public void confirmationFailureRollsBackEntryAndKeepsPending(){
        db.addPending(Payment.WECHAT,"待补记",100,"auto:pending");long id=db.pending().get(0).id;
        db.getWritableDatabase().execSQL("CREATE TRIGGER fail_event BEFORE INSERT ON events BEGIN SELECT RAISE(ABORT,'simulated write failure'); END");
        boolean failed=false;try{db.confirmPending(id,Payment.WECHAT,1200,100,"测试",Payment.WALLET,600000);}catch(RuntimeException expected){failed=true;}
        assertTrue(failed);assertEquals(0,count());assertEquals(1,db.pending().size());
        db.getWritableDatabase().execSQL("DROP TRIGGER fail_event");assertEquals("ADDED",db.confirmPending(id,Payment.WECHAT,1200,100,"测试",Payment.WALLET,600000).status);assertEquals(1,count());assertTrue(db.pending().isEmpty());
    }
    @Test public void ignoredNotificationDoesNotReturnAfterRestart(){
        db.addPending(Payment.WECHAT,"待处理",100,"auto:ignored");db.dismissPending(db.pending().get(0).id);db.close();db=new LedgerDb(context,name);
        assertFalse(db.addPending(Payment.WECHAT,"待处理",100,"auto:ignored"));assertEquals("REPEAT",db.record(p(Payment.AUTO,100,"auto:ignored",Payment.WALLET),600000).status);assertEquals(0,count());
    }
    @Test public void deletedAutomaticPaymentStaysDeletedOnReplay(){
        db.calibrate(Payment.WECHAT,10000,50);LedgerDb.Result r=db.record(p(Payment.AUTO,100,"auto:deleted",Payment.WALLET),600000);db.delete(r.entryId);
        assertEquals("REPEAT",db.record(p(Payment.AUTO,100,"auto:deleted",Payment.WALLET),600000).status);assertEquals(0,count());assertEquals(10000,db.account(Payment.WECHAT).balance);
    }
    @Test public void manualReplayGuardStillExpiresForANewRealPayment(){
        LedgerDb.Result r=db.record(p(Payment.MANUAL,100,"manual:same",Payment.UNKNOWN),600000);db.delete(r.entryId);
        assertEquals("REPEAT",db.record(p(Payment.MANUAL,50100,"manual:same",Payment.UNKNOWN),600000).status);
        assertEquals("ADDED",db.record(p(Payment.MANUAL,60100,"manual:same",Payment.UNKNOWN),600000).status);assertEquals(1,count());
    }
    @Test public void versionOneUpgradePreservesLedgerAndBalance(){
        db.calibrate(Payment.WECHAT,10000,50);db.record(p(Payment.AUTO,100,"old",Payment.WALLET),600000);
        db.getWritableDatabase().execSQL("DROP TABLE ignored_events");db.getWritableDatabase().execSQL("PRAGMA user_version=1");db.close();db=new LedgerDb(context,name);
        assertEquals(1,count());assertEquals(8800,db.account(Payment.WECHAT).balance);db.delete(db.entries(0,Long.MAX_VALUE).get(0).id);assertEquals(0,count());
    }
    @Test public void restoringTwoWalletPaymentsDeductsTwice(){
        db.calibrate(Payment.WECHAT,10000,50);db.record(p(Payment.MANUAL,100,"m",Payment.WALLET),600000);db.record(p(Payment.AUTO,110,"a",Payment.WALLET),600000);
        assertEquals(8800,db.account(Payment.WECHAT).balance);db.resolve(db.conflicts().get(0),true);assertEquals(7600,db.account(Payment.WECHAT).balance);assertEquals(2,count());
    }
    @Test public void correctedOldPaymentDoesNotDeductCalibratedBalanceAgain(){
        db.addPending(Payment.WECHAT,"旧付款",100,"manual:old");db.calibrate(Payment.WECHAT,10000,200);
        db.confirmPending(db.pending().get(0).id,Payment.WECHAT,1200,100,"旧付款",Payment.WALLET,600000);assertEquals(10000,db.account(Payment.WECHAT).balance);assertEquals(1,count());
    }
}
