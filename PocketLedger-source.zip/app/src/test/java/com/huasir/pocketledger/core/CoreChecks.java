package com.huasir.pocketledger.core;
import java.util.Objects;

/** Also runnable using only JDK 17: no Android SDK or third-party test runner needed. */
public final class CoreChecks {
    private static int count;
    private static void eq(Object expected,Object actual,String name){count++;if(!Objects.equals(expected,actual))throw new AssertionError(name+": expected="+expected+", actual="+actual);}
    private static void yes(boolean actual,String name){eq(true,actual,name);}
    private static void no(boolean actual,String name){eq(false,actual,name);}
    private static void rejects(String amount){count++;try{Money.parse(amount);throw new AssertionError("Accepted invalid amount "+amount);}catch(IllegalArgumentException|ArithmeticException expected){}}
    private static Payment parse(String text){return PaymentParser.parse(Payment.WECHAT,text,1_000_000,Payment.MANUAL,"x");}
    private static Payment p(String app,int origin,long cents,long time,String id){return new Payment(app,cents,time,origin,"shop",id,Payment.UNKNOWN,"","");}
    public static int run(){
        count=0;
        eq(100L,Money.parse("1"),"integer money");eq(1234L,Money.parse("12.34"),"decimal money");eq(10L,Money.parse("0.1"),"one decimal");eq(0L,Money.parse("0"),"zero balance");
        eq("12.34",Money.format(1234),"format money");eq("-0.01",Money.format(-1),"negative estimate");eq("0.00",Money.format(0),"format zero");
        for(String s:new String[]{"-1","1.001","abc","1e2","1,000","", "NaN","999999999999999999999"})rejects(s);
        yes(PaymentParser.success("付款成功"),"success");yes(PaymentParser.success("付 款 成 功"),"OCR spaced success");yes(PaymentParser.success("交易成功"),"transaction success");
        for(String text:new String[]{"付款失败","待支付 ¥12.00","支付中 ¥12.00","收款成功 ¥12.00","支付成功后退款 ¥12.00","收到转账 ¥12.00","转账成功 ¥12.00","充值成功 ¥12.00"})eq(null,parse(text),"non-expense ignored: "+text);
        Payment labelled=parse("付款成功\n付款金额：￥12.34\n优惠 ¥1.00\n支付方式：零钱\n收款方：小卖部");
        eq(1234L,labelled.cents,"prefer explicit paid amount");eq(Payment.WALLET,labelled.funding,"wallet funding");eq("小卖部",labelled.merchant,"merchant");
        eq(500L,parse("付款成功\n5.00").cents,"standalone main amount");
        eq(1200L,parse("付款成功\n¥12.00").cents,"currency amount");
        eq(1200L,parse("付款成功\n消费12元").cents,"integer yuan");
        eq(1200L,parse("付款成功\n金额：１２．００元").cents,"fullwidth OCR");
        eq(123456L,parse("付款成功\n实付：¥1,234.56").cents,"thousands separator");
        eq(null,parse("付款成功\n¥10.00\n¥20.00"),"ambiguous currency");
        eq(1000L,parse("付款成功\n实付10.00\n付款金额20.00").cents,"actual payment overrides pre-discount amount");
        eq(null,parse("付款成功\n实付10.00\n实际支付20.00"),"conflicting actual-payment labels");
        eq("",parse("付款成功\n¥12.00\n订单号："+"a".repeat(65)).orderId,"long order id cannot be truncated");
        eq(null,parse("付款成功\n¥0.00"),"zero expense");eq(null,parse("付款成功\n订单号：2026100100123456"),"order is not amount");
        eq(null,parse("付款成功\n¥10,00"),"bad separator");eq(null,parse("付款成功\n¥12.345"),"three decimal OCR not truncated");
        eq(null,parse("付款成功\n12.345元"),"yuan suffix cannot salvage invalid decimals");
        eq(null,parse("付款成功\n1,23元"),"yuan suffix cannot salvage invalid comma groups");
        eq(null,parse("付款成功\n202610011234元"),"long number cannot be truncated to money");
        eq(Payment.EXTERNAL,parse("付款成功\n¥12.00\n支付方式：招商银行卡").funding,"bankcard not wallet");
        eq(Payment.EXTERNAL,parse("付款成功\n¥12.00\n支付方式：余额宝").funding,"yuebao separate");
        eq(Payment.EXTERNAL,parse("付款成功\n¥12.00\n支付方式：零钱通").funding,"lingqiantong separate");
        eq(Payment.UNKNOWN,parse("付款成功\n¥12.00\n余额 500").funding,"balance mention alone not funding");
        eq("20261001123456789",parse("付款成功\n¥12.00\n微信支付交易单号：20261001123456789").orderId,"order id");
        yes(PaymentParser.candidateNotification(Payment.WECHAT,"微信支付","支付成功，消费12.00元"),"wechat pay notification");
        no(PaymentParser.candidateNotification(Payment.WECHAT,"朋友","支付成功，消费12.00元"),"normal chat ignored");
        no(PaymentParser.candidateNotification("fake.app","微信支付","支付成功12.00元"),"fake app ignored");
        no(PaymentParser.candidateNotification(Payment.WECHAT,"微信支付","收款成功12.00元"),"income notification ignored");
        yes(PaymentParser.candidateNotification(Payment.ALIPAY,"支付成功","你已支付12.00元"),"alipay success in title");
        Payment manual=p(Payment.WECHAT,Payment.MANUAL,1200,1_000_000,"");Payment auto=p(Payment.WECHAT,Payment.AUTO,1200,1_100_000,"");
        yes(DedupPolicy.matches(auto,manual,Payment.MANUAL,600_000),"manual then auto");
        yes(DedupPolicy.matches(manual,auto,Payment.AUTO,600_000),"auto then manual");
        no(DedupPolicy.matches(auto,auto,Payment.AUTO,600_000),"two equal-price automatic payments");
        no(DedupPolicy.matches(manual,manual,Payment.MANUAL,600_000),"two equal-price manual payments");
        no(DedupPolicy.matches(auto,manual,3,600_000),"consumed pair not reused");
        no(DedupPolicy.matches(p(Payment.ALIPAY,Payment.AUTO,1200,1_100_000,""),manual,1,600_000),"different apps");
        no(DedupPolicy.matches(p(Payment.WECHAT,Payment.AUTO,1201,1_100_000,""),manual,1,600_000),"different amounts");
        no(DedupPolicy.matches(p(Payment.WECHAT,Payment.AUTO,1200,1_700_000,""),manual,1,600_000),"outside window");
        yes(DedupPolicy.matches(p(Payment.WECHAT,Payment.AUTO,1200,1_600_000,""),manual,1,600_000),"inclusive window boundary");
        no(DedupPolicy.matches(p(Payment.WECHAT,Payment.AUTO,1200,1_100_000,"order-b"),p(Payment.WECHAT,Payment.MANUAL,1200,1_000_000,"order-a"),1,600_000),"different order ids override amount");
        yes(DedupPolicy.matches(p(Payment.WECHAT,Payment.AUTO,1200,9_000_000,"order-a"),p(Payment.WECHAT,Payment.MANUAL,1200,1_000_000,"order-a"),1,600_000),"same order beyond window");
        no(DedupPolicy.matches(p(Payment.WECHAT,Payment.TYPED,1200,1_000_000,""),manual,1,600_000),"typed correction is independent");
        return count;
    }
    public static void main(String[] args){System.out.println("PASS: "+run()+" core assertions");}
}
