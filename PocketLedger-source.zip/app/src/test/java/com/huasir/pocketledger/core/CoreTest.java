package com.huasir.pocketledger.core;
import org.junit.Test;
public class CoreTest {@Test public void financialAndDedupRules(){CoreChecks.run();}}
