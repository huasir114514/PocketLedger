param([string]$AndroidSdk = '', [string]$JavaHomePath = '')
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
if (-not $JavaHomePath) {
    $studioJava = Join-Path $env:ProgramFiles 'Android/Android Studio/jbr'
    if (Test-Path (Join-Path $studioJava 'bin/java.exe')) { $JavaHomePath = $studioJava }
    elseif ($env:JAVA_HOME) { $JavaHomePath = $env:JAVA_HOME }
}
if ($JavaHomePath) { $env:JAVA_HOME = $JavaHomePath; $env:PATH = (Join-Path $JavaHomePath 'bin') + ';' + $env:PATH }
$oldError = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$versionOutput = (& java -version 2>&1 | Out-String)
$ErrorActionPreference = $oldError
if ($versionOutput -notmatch 'version "(17|21)\.') { throw 'Please use JDK 17 or 21. Use -JavaHomePath to select it. Java 25 is not supported by this Gradle version.' }
if (-not $AndroidSdk) {
    if ($env:ANDROID_HOME) { $AndroidSdk = $env:ANDROID_HOME }
    elseif ($env:ANDROID_SDK_ROOT) { $AndroidSdk = $env:ANDROID_SDK_ROOT }
    else { $AndroidSdk = Join-Path $env:LOCALAPPDATA 'Android/Sdk' }
}
if (-not (Test-Path (Join-Path $AndroidSdk 'platforms/android-35/android.jar'))) { throw 'Install Android SDK Platform 35 and Build Tools 35.0.0 in Android Studio SDK Manager first.' }
$env:ANDROID_HOME = $AndroidSdk
$taskTools = Join-Path $taskRoot '.tools'
$taskGradle = Join-Path $taskTools 'gradle-8.11.1/bin/gradle.bat'
if (-not (Test-Path $taskGradle)) {
    New-Item -ItemType Directory -Path $taskTools -Force | Out-Null
    $taskZip = Join-Path $taskTools 'gradle-8.11.1-bin.zip'
    Write-Host 'Downloading Gradle 8.11.1 from the official distribution server...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $taskZip -UseBasicParsing
    $expectedHash = 'f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6'
    if ((Get-FileHash $taskZip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { Remove-Item $taskZip; throw 'Gradle checksum verification failed.' }
    Expand-Archive $taskZip -DestinationPath $taskTools -Force
    Remove-Item $taskZip
}
Push-Location $taskRoot
try {
    # Generates the genuine Gradle wrapper for subsequent Android Studio imports.
    & $taskGradle --no-daemon wrapper --gradle-version 8.11.1 --distribution-type bin --gradle-distribution-sha256-sum f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6
    if ($LASTEXITCODE -ne 0) { throw 'Gradle wrapper generation failed. Check access to Google Maven and Maven Central.' }
    & $taskGradle --no-daemon testDebugUnitTest lintDebug assembleDebug
    if ($LASTEXITCODE -ne 0) { throw 'Android build failed. See the error above.' }
    Write-Host ('APK ready: ' + (Join-Path $taskRoot 'app/build/outputs/apk/debug/app-debug.apk'))
} finally { Pop-Location }
